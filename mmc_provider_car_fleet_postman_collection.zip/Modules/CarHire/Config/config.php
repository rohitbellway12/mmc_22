<?php

return [
    'name' => 'CarHire',
];
