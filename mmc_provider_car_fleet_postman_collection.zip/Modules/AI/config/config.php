<?php

return [
    'name' => 'AI',
];
